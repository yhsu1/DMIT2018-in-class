﻿namespace EatIn.UI
{
    public delegate void ProcessRequest();
}